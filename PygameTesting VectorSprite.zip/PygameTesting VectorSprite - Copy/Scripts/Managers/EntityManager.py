import pygame
import bisect

# Adding and removing entities and also rendering them
class EntityManager:
    def __init__(self):
        self.entities = list()
        
    def AddEntity(self, entity):
        bisect.insort(self.entities, entity)
        
    def RemoveEntity(self, entity):
        self.entities.remove(entity)
        
    def UpdateEntities(self, deltaTime):
        for entity in self.entities:
            entity.Update(deltaTime)
        
    def RenderEntities(self, surface):
        for entity in self.entities:
            entity.Render(surface)