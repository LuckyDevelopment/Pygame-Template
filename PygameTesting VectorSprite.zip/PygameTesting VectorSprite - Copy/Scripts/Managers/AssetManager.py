import pygame
import Scripts.Core.Utils as Utils

# Holds and does most things with assets in the game.
class AssetManager:
    def __init__(self):
        pass
    
    # Stores all assets for the game
    def LoadAssets(self):
        return {
            'images': {
                'player': Utils.LoadImage('player.png'),
                'player2': Utils.LoadImage('player2.png')
            }
        }