import pygame
import sys
import Scripts.Drawing.Entities as Entities
import Scripts.Managers.AssetManager as AssetManager
import Scripts.Managers.EntityManager as EntityManager

class Game:
    # Constructor
    def __init__(self):
        # Create new window
        pygame.init()
        pygame.display.set_caption("Test Window")
        
        # Create screen and variables.
        self.screen = pygame.display.set_mode((800, 600))
        self.display = pygame.Surface((400, 300)) # To increase pixelation, change the main render resolution to be a factor of the main game resolution above.
        self.targetFrameRate = 60
        self.currentFrame = 0
        self.clock = pygame.time.Clock()
        self.gameRunning = True
        self.deltaTime = 0.1
        
        # Create managers and load assets
        self.entityManager = EntityManager.EntityManager()
        self.assets = AssetManager.AssetManager().LoadAssets()
        
        
        
        # Example creating 2 image entity and a rect. Use asset manager for new images.
        player1 = Entities.ImageEntity(self, (80, 50), (25, 25), 'images/player')
        player1.zIndex = 6
        self.entityManager.AddEntity(player1)
        
        self.player2 = Entities.ImageEntity(self, (65, 50), (25, 25), 'images/player2')
        self.player2.zIndex = 5
        self.entityManager.AddEntity(self.player2)
        
        # An example of creating a rect
        self.rect = Entities.BasicCircle(self, (300, 50), 50, (255, 0, 0))
        self.entityManager.AddEntity(self.rect)
        
        
        
        
    # Called every frame to update game.
    def update(self):
        while self.gameRunning:
            #Background
            self.display.fill((255, 255, 255))

            # Handle events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.gameRunning = False
                    break
        
            # Render entities
            self.entityManager.UpdateEntities(self.deltaTime)
            self.entityManager.RenderEntities(self.display)

            # Update buffers and deltaTime
            self.deltaTime = max(0.0001, min(0.1, self.clock.tick(self.targetFrameRate) / 1000))
            self.screen.blit(pygame.transform.scale(self.display, self.screen.get_size()), (0, 0))
            pygame.display.update()
            self.currentFrame += 1
        
        # Quit game
        pygame.quit()
        sys.exit()
            
            
Game().update()