import pygame
import random

# An entity with position, size and velocity.
class Entity:
    # Constructor
    def __init__(self, game, entityType, position, size):
        self.game = game
        self.type = entityType
        self.position = list(position)
        self.size = list(size)
        self.velocity = [0, 0]
        self.zIndex = 0
        self.rect = pygame.Rect(self.position[0], self.position[1], self.size[0], self.size[1])
    
    # Compares two entities based on zIndex.
    def __lt__(self, other):
        return self.zIndex < other.zIndex
    
    # Returns if the rect is on screen, can be used for circles if you use a custom UpdateRect
    def OnScreen(self, surface):
        return self.rect.colliderect(surface.get_rect())
    
    # Update the rect for not rendering it if it's off screen.
    def UpdateRect(self):
        self.rect.topleft = (self.position[0], self.position[1])
        
    # Update the entity every frame.
    def Update(self, deltaTime):
        pass
    
    # Render the entity every frame.
    def Render(self, surface):
        pass
    
    
    
    
    
    
# A entity that is an image.
class ImageEntity(Entity):
    # Constructor
    def __init__(self, game, position, size, imageFile):
        super().__init__(game, "ImageEntity", position, size)
        splitPath = imageFile.split("/")
        self.image = pygame.transform.scale(self.game.assets[splitPath[0]][splitPath[1]], (size[0], size[1]))
    
    # Update entity every frame.
    def Update(self, deltaTime):
        super().Update(deltaTime)
        self.UpdateRect()
        
    # Render entity every frame.
    def Render(self, surface):
        if self.OnScreen(surface):
            surface.blit(self.image, (self.position[0], self.position[1]))





# A basic rectangle class
class BasicRect(Entity):
    # Constructor
    def __init__(self, game, position, size, color):
        super().__init__(game, "BasicRect", position, size)
        self.color = tuple(color)
    
    # Update entity every frame
    def Update(self, deltaTime):
        super().Update(deltaTime)
        self.UpdateRect()
        
    # Render entity every frame
    def Render(self, surface):
        if self.OnScreen(surface):
            pygame.draw.rect(surface, self.color, (self.position[0], self.position[1], self.size[0], self.size[1]))
    
    
    
    
        
            
# A basic rectangle class
class BasicCircle(Entity):
    # Constructor
    def __init__(self, game, position, radius, color):
        super().__init__(game, "BasicCircle", position, (radius * 2,  radius * 2))
        self.color = tuple(color)
        self.radius = radius
        self.rect = pygame.Rect(self.position[0] - radius, self.position[1] - radius, self.size[0], self.size[1])
        
    # Update entity every frame
    def Update(self, deltaTime):
        super().Update(deltaTime)
        self.rect.topleft = (self.position[0] - self.radius, self.position[1] - self.radius)
        
    # Render entity every frame
    def Render(self, surface):
        if self.OnScreen(surface):
            pygame.draw.circle(surface, self.color, (self.position[0], self.position[1]), self.radius)
        